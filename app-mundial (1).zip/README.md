# Global Food Guide 🌍 (nome provisório)

Guia alimentar internacional: receitas, produtos de supermercado, equivalentes entre países,
substitutos de ingredientes, tradução de nomes, listas de compras, guia de chás e recursos de viagem.

- 📄 Especificação: [PROJECT_SPEC.md](PROJECT_SPEC.md)
- 🛠️ Como rodar: [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md)
- 🧭 Decisões técnicas: [docs/decisions](docs/decisions/README.md)

## Status

🚧 **Fase 0 — Fundação** em andamento.
